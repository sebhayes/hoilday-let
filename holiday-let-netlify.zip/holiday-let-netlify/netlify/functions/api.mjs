// The site's API. The owner signs in with OWNER_PASSWORD; the cleaner uses a private link.
import { createHash, timingSafeEqual, randomBytes } from "node:crypto";
import { load, save, syncFeeds, notify, publicState, today } from "../../lib/core.mjs";
import { SOURCES, isDate, cleansICS } from "../../lib/logic.mjs";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

const sameKey = (a, b) => {
  if (!a || !b) return false;
  const h = (s) => createHash("sha256").update(String(s)).digest();
  return timingSafeEqual(h(a), h(b));
};
const str = (v, max) => String(v == null ? "" : v).trim().slice(0, max);
const time = (v, fallback) => (/^\d{2}:\d{2}$/.test(v || "") ? v : fallback);

export default async (req) => {
  const url = new URL(req.url);
  const route = url.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  const password = process.env.OWNER_PASSWORD;
  if (!password) return json({ error: "Set OWNER_PASSWORD in Netlify's environment variables, then redeploy." }, 500);

  let state;
  try {
    state = await load();
  } catch (e) {
    console.error(e);
    return json({ error: "Storage could not be reached. Try again in a moment." }, 503);
  }

  // Calendar feed the cleaner can subscribe to from their phone.
  if (route === "cleans.ics") {
    if (!sameKey(url.searchParams.get("k"), state.cleanerKey)) return new Response("Not found", { status: 404 });
    return new Response(cleansICS(state, today(state), url.hostname), {
      headers: { "content-type": "text/calendar; charset=utf-8", "cache-control": "no-store" },
    });
  }

  const key = req.headers.get("x-key") || "";
  const role = sameKey(key, password) ? "owner" : sameKey(key, state.cleanerKey) ? "cleaner" : null;
  if (!role) return json({ error: "Wrong password." }, 401);

  if (req.method === "GET" && route === "state") return json(publicState(state, role));
  if (req.method !== "POST") return json({ error: "Not found." }, 404);

  let body = {};
  try {
    body = (await req.json()) || {};
  } catch {}
  let message = "";

  if (route === "done") {
    const id = str(body.id, 200);
    if (!state.bookings[id]) return json({ error: "That clean no longer exists." }, 404);
    state.cleans[id] = body.done ? { done: true, doneAt: new Date().toISOString(), by: role } : { done: false };
  } else if (role !== "owner") {
    return json({ error: "Only the owner can do that." }, 403);
  } else if (route === "booking") {
    const { checkIn, checkOut } = body;
    if (!isDate(checkIn) || !isDate(checkOut)) return json({ error: "Choose both dates." }, 400);
    if (checkOut <= checkIn) return json({ error: "The leaving date must be after the arrival date." }, 400);
    const id = body.id ? str(body.id, 200) : `direct-${randomBytes(6).toString("hex")}`;
    if (body.id && !state.bookings[id]) return json({ error: "That booking no longer exists." }, 404);
    const old = state.bookings[id] || {};
    state.bookings[id] = {
      ...old,
      guest: str(body.guest, 80),
      checkIn,
      checkOut,
      source: SOURCES[body.source] ? body.source : "direct",
      cleanNote: str(body.cleanNote, 500),
    };
    const clash = Object.entries(state.bookings).some(([k, b]) => k !== id && checkIn < b.checkOut && b.checkIn < checkOut);
    message = clash ? "Saved. These dates overlap another booking." : "Saved.";
    const mail = await notify(state);
    if (mail.sent) message += " Cleaner emailed.";
  } else if (route === "booking-delete") {
    const id = str(body.id, 200);
    delete state.bookings[id];
    delete state.cleans[id];
    message = "Booking deleted.";
    const mail = await notify(state);
    if (mail.sent) message += " Cleaner emailed.";
  } else if (route === "settings") {
    const f = body.feeds || {};
    state.settings = {
      ...state.settings,
      property: str(body.property, 80),
      checkout: time(body.checkout, state.settings.checkout),
      checkin: time(body.checkin, state.settings.checkin),
      cleanerName: str(body.cleanerName, 60),
      cleanerEmail: str(body.cleanerEmail, 120),
      ownerEmail: str(body.ownerEmail, 120),
      autoEmail: body.autoEmail !== false,
      feeds: { airbnb: str(f.airbnb, 600), booking: str(f.booking, 600), vrbo: str(f.vrbo, 600) },
    };
    message = "Saved.";
  } else if (route === "sync") {
    const totals = await syncFeeds(state);
    const mail = await notify(state);
    const failed = Object.keys(state.syncErrors).map((s) => SOURCES[s]);
    message = `${totals.added} added, ${totals.changed} changed, ${totals.removed} removed.`;
    if (failed.length) message += ` Could not read: ${failed.join(", ")}.`;
    if (mail.sent) message += " Cleaner emailed.";
  } else if (route === "email-schedule") {
    const mail = await notify(state, { force: true });
    if (!mail.sent) {
      await save(state);
      return json({ ...publicState(state, role), error: mail.error || "The email could not be sent." });
    }
    message = "Schedule emailed to your cleaner.";
  } else if (route === "new-cleaner-link") {
    state.cleanerKey = randomBytes(18).toString("base64url");
    message = "New cleaner link created. The old one has stopped working.";
  } else {
    return json({ error: "Not found." }, 404);
  }

  await save(state);
  return json({ ...publicState(state, role), message });
};

export const config = { path: "/api/*" };
