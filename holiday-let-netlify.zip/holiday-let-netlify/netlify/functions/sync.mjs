// Runs every hour: fetch the booking calendars, then email the cleaner if cleans changed.
import { load, save, syncFeeds, notify } from "../../lib/core.mjs";

export default async () => {
  const state = await load();
  const totals = await syncFeeds(state);
  const mail = await notify(state);
  await save(state);
  console.log("sync", JSON.stringify({ totals, errors: state.syncErrors, mail }));
};

export const config = { schedule: "@hourly" };
