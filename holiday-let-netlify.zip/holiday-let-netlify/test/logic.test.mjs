import assert from "node:assert/strict";
import { normalise, parseICS, applyFeed, computeCleans, diffCleans, buildEmail, cleansICS } from "../lib/logic.mjs";

const today = "2026-11-14";
const ics = (events) =>
  "BEGIN:VCALENDAR\r\nVERSION:2.0\r\n" +
  events.map((e) => `BEGIN:VEVENT\r\nDTSTART;VALUE=DATE:${e[0]}\r\nDTEND;VALUE=DATE:${e[1]}\r\nUID:${e[2]}\r\nSUMMARY:${e[3]}\r\nEND:VEVENT\r\n`).join("") +
  "END:VCALENDAR\r\n";

const state = normalise({});

// Airbnb: one stay, one owner block (ignored), one long-past stay (ignored).
let evs = parseICS(ics([["20261120", "20261124", "a1@airbnb.com", "Reserved"], ["20261201", "20261203", "a2@airbnb.com", "Airbnb (Not available)"], ["20260101", "20260105", "a0@airbnb.com", "Reserved"]]), "airbnb", today);
assert.equal(evs.length, 1);
assert.deepEqual(applyFeed(state, "airbnb", evs, today), { added: 1, changed: 0, removed: 0, skipped: 0 });

// Booking.com repeats the Airbnb stay (skipped) and adds a same-day follow-on.
evs = parseICS(ics([["20261120", "20261124", "b1", "CLOSED - Not available"], ["20261124", "20261128", "b2", "CLOSED - Not available"]]), "booking", today);
assert.deepEqual(applyFeed(state, "booking", evs, today), { added: 1, changed: 0, removed: 0, skipped: 1 });

let cleans = computeCleans(state);
assert.deepEqual(cleans.map((c) => [c.date, c.gap]), [["2026-11-24", 0], ["2026-11-28", null]]);

// First email lists both as new; after "sending", nothing is pending.
let diff = diffCleans(state, today);
assert.equal(diff.added.length, 2);
const mail = buildEmail(state, diff, "https://example.netlify.app/#c=x");
assert.match(mail.text, /NEW/);
assert.match(mail.text, /same day/);
state.notified = diff.current;
assert.equal(diffCleans(state, today).any, false);

// Booking.com reissues the uid for the same dates: nothing should change.
evs = parseICS(ics([["20261124", "20261128", "b2-new", "CLOSED - Not available"]]), "booking", today);
assert.deepEqual(applyFeed(state, "booking", evs, today), { added: 0, changed: 0, removed: 0, skipped: 0 });
assert.equal(diffCleans(state, today).any, false);

// The Booking.com stay is cancelled: its clean is cancelled and the first clean changes.
assert.deepEqual(applyFeed(state, "booking", [], today), { added: 0, changed: 0, removed: 1, skipped: 0 });
diff = diffCleans(state, today);
assert.deepEqual(diff.cancelled, ["2026-11-28"]);
assert.equal(diff.changed.length, 1);
assert.match(buildEmail(state, diff, "").text, /CANCELLED/);

// Airbnb stay extended by a day: the clean moves.
evs = parseICS(ics([["20261120", "20261125", "a1@airbnb.com", "Reserved"]]), "airbnb", today);
assert.deepEqual(applyFeed(state, "airbnb", evs, today), { added: 0, changed: 1, removed: 0, skipped: 0 });
assert.equal(computeCleans(state)[0].date, "2026-11-25");

assert.match(cleansICS(state, today, "example.netlify.app"), /DTSTART;VALUE=DATE:20261125/);

// Sunday checkout (22 Nov 2026): clean moves to Monday 23rd.
const sun = normalise({ bookings: { a: { source: "direct", checkIn: "2026-11-18", checkOut: "2026-11-22" }, b: { source: "direct", checkIn: "2026-11-23", checkOut: "2026-11-27" } } });
let sc = computeCleans(sun);
assert.deepEqual([sc[0].date, sc[0].moved, sc[0].gap], ["2026-11-23", true, 0]);
assert.deepEqual([sc[1].date, sc[1].moved], ["2026-11-27", false]);
// Next guests arrive on the Sunday itself: flagged as arriving before the clean.
sun.bookings.b.checkIn = "2026-11-22";
sc = computeCleans(sun);
assert.equal(sc[0].gap, -1);
assert.match(buildEmail(sun, diffCleans(sun, today), "").text, /WARNING: the next guests arrive Sun 22 Nov, before this clean/);
assert.match(buildEmail(sun, diffCleans(sun, today), "").text, /Monday 23 November: Guests leave on Sunday 22 Nov, so the clean is on the Monday/);
console.log("all logic tests passed");
