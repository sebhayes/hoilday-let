# Holiday Let Changeovers

A private site for one holiday let. It pulls bookings from Airbnb, Booking.com and Vrbo every hour, schedules a changeover clean on every checkout day, and emails your cleaner when a clean is added, changed or cancelled.

- **You** sign in with a password and see bookings, the calendar and setup.
- **Your cleaner** opens a private link (no account) and sees only the cleans, with no guest names. They can tick cleans off and subscribe to them in their phone calendar.

## Put it on Netlify

Dragging the folder onto Netlify will not work, because the site has server functions that Netlify must build. Deploy it from GitHub instead.

1. **GitHub:** create a free account at github.com, make a new **private** repository, and upload everything in this folder (Add file, Upload files). Leave out `node_modules` if you have one.
2. **Netlify:** create a free account at netlify.com. Choose Add new project, Import an existing project, GitHub, and pick the repository. Leave the build settings as they are and deploy.
3. **Password:** in Netlify go to Project configuration, Environment variables, and add `OWNER_PASSWORD`. Use a long one, since it is all that protects the site.
4. **Redeploy:** Deploys, Trigger deploy, Deploy project. Environment variables only take effect on a new deploy.
5. Open your site address, sign in, and fill in **Setup**: property name, times, cleaner details and the three calendar links. Press **Save setup**, then **Check calendars now**.
6. Copy **Your cleaner's link** from Setup and send it to your cleaner.

## Switch on email

Emails are sent through Resend (resend.com), which has a free tier.

1. Create a Resend account and an API key.
2. In Netlify add the environment variable `RESEND_API_KEY` with that key, then redeploy.

At this point email is in **test mode**: Resend only delivers to the address you signed up with. That is enough to check it works (put your own address in as the cleaner's email). To email your cleaner directly:

3. In Resend, add and verify a domain you own (it gives you DNS records to add).
4. In Netlify add `EMAIL_FROM`, for example `Harbour Cottage <bookings@yourdomain.co.uk>`, then redeploy.

No domain? Leave your own address as the cleaner's email and forward the messages, or rely on the cleaner's link and calendar subscription, which need no email at all.

## Environment variables

| Name | Needed | What it is |
| --- | --- | --- |
| `OWNER_PASSWORD` | Yes | Your sign-in password |
| `RESEND_API_KEY` | For email | API key from Resend |
| `EMAIL_FROM` | To email anyone but yourself | Sender on a domain verified in Resend |

## How it behaves

- **Hourly check.** Each calendar link is fetched every hour. New stays are added, changed dates are updated, and cancelled future stays are removed. If a calendar fails to load, its bookings are left alone and a warning shows on the site.
- **One clean per booking**, on the checkout day. If guests leave on a Sunday, the clean is on the Monday instead. Same-day changeovers are flagged, and so is a Monday clean when the next guests already arrived on the Sunday.
- **Emails.** One email per update, listing what is new, changed or cancelled, followed by the full schedule. Saving a note or a hand-entered booking emails straight away. Turn automatic emails off under Setup and use **Email full schedule** instead if you prefer.
- **Duplicates.** If the same dates appear on two calendars (because the sites sync with each other), the stay is only counted once.
- **Booking.com blocks.** Booking.com's calendar does not distinguish real stays from dates you blocked yourself, so blocked dates appear as bookings and get a clean. Airbnb and Vrbo blocks are ignored.
- **Guest names.** Airbnb's calendar only says "Reserved". Add the name yourself with **Edit or add a note** if you want it.
- **Storage.** Everything is kept in Netlify Blobs, which needs no setup.

## Files

- `public/index.html`: the whole front end
- `netlify/functions/api.mjs`: sign-in, bookings, settings, cleaner's calendar feed
- `netlify/functions/sync.mjs`: the hourly check
- `lib/logic.mjs`: calendar parsing, clean schedule, email wording
- `lib/core.mjs`: storage, fetching calendars, sending email
- `test/logic.test.mjs`: run with `npm test`
